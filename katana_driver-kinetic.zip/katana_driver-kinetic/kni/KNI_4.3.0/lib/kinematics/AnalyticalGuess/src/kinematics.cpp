/***************************************************************************
 *   Copyright (C) 2008 by Neuronics AG                                    *
 *   support@neuronics.ch                                                  *
 ***************************************************************************/

#include "kinematics.h"
//#include <iostream>

namespace AnaGuess {

} // namespace
