^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package katana_tutorials
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.1 (2017-05-26)
------------------

1.1.0 (2017-05-26)
------------------

1.0.8 (2017-05-26)
------------------

1.0.7 (2017-02-11)
------------------

1.0.6 (2017-01-27)
------------------
* Initial release to Kinetic
* Contributors: Martin Günther

1.0.5 (2016-04-12)
------------------

1.0.4 (2016-04-11)
------------------

1.0.3 (2015-06-29)
------------------
* remove dependencies to non-existing cmake targets
* Contributors: Michael Görner

1.0.2 (2015-05-06)
------------------

1.0.1 (2015-03-17)
------------------

1.0.0 (2015-03-16)
------------------
* Initial release to Debian packages
* Contributors: Martin Günther, Henning Deeken, Jochen Sprickerhof, Michael Görner
